integrated\_gui module
======================

.. automodule:: integrated_gui
   :members:
   :show-inheritance:
   :undoc-members:
