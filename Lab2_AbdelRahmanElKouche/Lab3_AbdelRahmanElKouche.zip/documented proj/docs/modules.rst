documented proj
===============

.. toctree::
   :maxdepth: 4

   database_manager
   integrated_gui
   pyqt_gui
   school_management
