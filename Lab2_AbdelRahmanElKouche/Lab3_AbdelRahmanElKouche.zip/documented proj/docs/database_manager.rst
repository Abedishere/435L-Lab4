database\_manager module
========================

.. automodule:: database_manager
   :members:
   :show-inheritance:
   :undoc-members:
