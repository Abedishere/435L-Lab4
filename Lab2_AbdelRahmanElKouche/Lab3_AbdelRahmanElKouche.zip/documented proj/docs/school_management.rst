school\_management module
=========================

.. automodule:: school_management
   :members:
   :show-inheritance:
   :undoc-members:
